
function counterReducer(prevState = { count: 0 }, action) {
  return { count: 1 };
}

export default counterReducer;
