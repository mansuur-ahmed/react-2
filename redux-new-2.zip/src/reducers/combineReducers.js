import { combinereducers, combineReducers } from "redux";

import userDetailsReducer from "./userDetailsReducer";
import counterReducer from "./counterReducer";

export default combineReducers({
  user: userDetailsReducer,
  counter: counterReducer
});
