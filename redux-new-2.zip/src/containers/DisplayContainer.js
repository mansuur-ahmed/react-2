import { connect } from "react-redux";
import Display from "../components/Display";

function mapStateToprops(state) {
  return {
    fetching: state.fetching,
    userDetails: state.userDetails,
    error: state.error
  };
}

const DisplayContainer = connect(mapStateToprops)(Display);

export default DisplayContainer;
