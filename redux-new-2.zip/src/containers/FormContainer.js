import { connect } from "react-redux";

import Form from "../components/Form";
import getUserDetailsActions from "../actions/userDetailsActions";

function mapStateToProps(state) {
  return {};
}

function mapDispatchToProps(dispatch) {
  return {
    getUserDetails: url => {
      dispatch(getUserDetailsActions(url));
    }
  };
}

const FormContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(Form);

export default FormContainer;
