const customLogger = store => next => action => {
  console.log("prevState: ", store.getState());
  console.log("newState: ", store.getState());
  next({ type: "DECREMENT" });
  console.log("prevState: ", store.getState());
};
