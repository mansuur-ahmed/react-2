import React from "react";

class Display extends React.Component {
  render() {
    console.log("Display props: ", this.props);
    const { fetching, userDetails, error } = this.props;
    return (
      <div>
        {fetching && (
          <h3 style={{ color: "blue" }}>
            Please Wait.... User Details is getting fetched
          </h3>
        )}
        {error && <h3 style={{ color: "red" }}>Error!!!</h3>}
        {userDetails.name && (
          <ul style={{ color: "green" }}>
            <li>
              Name:
              {userDetails.name}
            </li>
            <li>Location: {userDetails.location}</li>
            <li>Blog: {userDetails.blog}</li>
          </ul>
        )}
      </div>
    );
  }
}

export default Display;
