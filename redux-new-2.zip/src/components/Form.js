import React from "react";

class Form extends React.Component {
  render() {
    return (
      <form>
        <input
          type="text"
          size={40}
          defaultValue="https://api.github.com/users/gaearon"
          ref={node => {
            this.urltextbox = node;
          }}
        />
        &nbsp;&nbsp;
        <br />
        <br />
        <input
          type="button"
          value="Get User Details..."
          onClick={() => {
            this.props.getUserDetails(this.urltextbox.value);
          }}
        />
        <hr />
      </form>
    );
  }
}

export default Form;
