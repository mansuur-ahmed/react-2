import axios from "axios";
export default function getUserDetailsActions(url) {
  // return { type: "get user data", url };
  console.log("url is --------- ", url);
  return function(dispatch) {
    dispatch({ type: "IS_FETCHING" });
    axios
      .get(url)
      .then(response => {
        dispatch({ type: "FETCH_SUCCESS", userDetails: response.data });
      })
      .catch(error => {
        dispatch({ type: "FETCH_ERROR", error: error.message });
      });
  };
}
