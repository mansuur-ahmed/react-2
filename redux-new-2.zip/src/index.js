import React from "react";
import ReactDOM from "react-dom";
import { createStore, applyMiddleware } from "redux";
import { Provider } from "react-redux";
import { composeWithDevTools } from "redux-devtools-extension";
import logger from "redux-logger";
import thunk from "redux-thunk";
import App from "./components/App";
import userDetailsReducer from "./reducers/userDetailsReducer";

const spaStore = createStore(
  userDetailsReducer,
  composeWithDevTools(applyMiddleware(logger, thunk))
);
//const spaStore = createStore(counterReducer);

ReactDOM.render(
  <Provider store={spaStore}>
    <App />
  </Provider>,
  document.getElementById("app")
);

// STORE:{
//   fecthing:false,
//   userDetails:{},
//   error:""
// }

// ACTIONS:
// { type: "IS_FETCHING"}
// { type: "FETCH_SUCCESS", userDetails:{name:"Mansoor",location:"chennai",blog:"myblog"}}
// { type: "FETCH_ERROR", error:"error"}
