import React from "react";
import { Switch } from "react-router-dom";
import { Route } from "react-router-dom";
import department from "./department";
import employee from "./employee";
import logout from "./logout";
import login from "./login";

class Section extends React.Component {
  render() {
    return (
      <section class="content">
        <Switch>
          <Route path="/" exact component={login} />
          <Route path="/logout" component={logout} />
          <Route path="/department" component={department} />
          <Route path="/employee" component={employee} />
          <Route
            path=""
            render={() => {
              return <h3 style={{ color: "red" }}>404-Page not Found</h3>;
            }}
          />
        </Switch>
      </section>
    );
  }
}

export default Section;

{
  /* <form action="">
        <div class="form-input">
          <label>Username:</label>
          <input type="text" />
        </div>

        <div class="form-input">
          <label>Password:</label>
          <input type="password" />
        </div>

        <div class="form-input">
          <input type="button" value="Login" />
          <input type="button" value="Reset" />
        </div>
      </form> */
}
