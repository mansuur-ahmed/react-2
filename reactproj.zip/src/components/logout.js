import React from "react";
import { Redirect } from "react-router-dom";
// import Display from "./Display";
// import KeyDemo from "./KeyDemo";

class logout extends React.Component {
  render() {
    return <Redirect to="/" />;
  }
}

export default logout;
