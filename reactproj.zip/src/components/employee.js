import React from "react";
import Nav from "./nav";
import Section from "./section";
import Header from "./header";
// import Display from "./Display";
// import KeyDemo from "./KeyDemo";

class employee extends React.Component {
  render() {
    return <h>Employee !!</h>;
  }
}

export default employee;
