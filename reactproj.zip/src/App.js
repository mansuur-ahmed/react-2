import React from "react";
import Nav from "./components/nav";
import Section from "./components/section";
import Header from "./components/header";
import login from "./components/login";
// import Display from "./Display";
// import KeyDemo from "./KeyDemo";

class App extends React.Component {
  render() {
    return (
      <main class="main">
        <Header />
        <Nav />
        <Section />
      </main>
    );
  }
}

export default App;
